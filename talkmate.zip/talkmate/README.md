# 💬 토크메이트 (TalkMate)

상황극(롤플레이)으로 연습하는 AI 외국어 회화 파트너입니다.
OpenRouter API 키 하나로 **Gemini 3.8 Flash**(대화 상대), **GPT-6 Luna**(문장 교정·힌트·번역), **Claude Sonnet 5.5**(대화 후 리포트)를 사용합니다.

- 로그인·서버·DB가 없습니다. 브라우저만으로 동작합니다.
- API 키는 화면에서 직접 입력합니다. 기본은 **이번 세션만**(sessionStorage, 탭을 닫으면 삭제)이고, 원하면 **이 기기에 저장**(localStorage)할 수 있습니다.
- 대화 기록과 리포트는 **PDF · Word · Excel** 파일로 내 PC에 저장합니다.

## 파일 구성

| 파일 | 설명 |
|---|---|
| `index.html` | 화면 구조 |
| `style.css` | 디자인(밝은·어두운 테마, 모바일 대응, 인쇄용 스타일) |
| `app.js` | 모든 기능(OpenRouter 호출, 음성 인식·합성, 교정, 리포트, 내보내기) |

빌드 과정이 없습니다. 세 파일을 같은 폴더에 두면 됩니다.

## GitHub Pages로 배포하기

1. GitHub에서 새 저장소를 만듭니다(예: `talkmate`).
2. 이 폴더의 파일(`index.html`, `style.css`, `app.js`, `README.md`)을 저장소 최상위에 올립니다.
   ```bash
   git init
   git add index.html style.css app.js README.md
   git commit -m "토크메이트 첫 버전"
   git branch -M main
   git remote add origin https://github.com/<사용자명>/talkmate.git
   git push -u origin main
   ```
3. 저장소의 **Settings → Pages**에서 Source를 `Deploy from a branch`, Branch를 `main` / `/(root)`로 정하고 저장합니다.
4. 1~2분 뒤 `https://<사용자명>.github.io/talkmate/`로 접속합니다.

> 마이크(음성 인식)는 **HTTPS 주소**에서만 안정적으로 동작합니다. GitHub Pages는 HTTPS이므로 그대로 쓰면 됩니다.
> PC에서 파일을 바로 열면(`file://`) 마이크 권한이 거부될 수 있으니, 이때는 폴더에서 `python -m http.server 8000`을 실행한 뒤 `http://localhost:8000`으로 여세요.

## 사용 방법

1. OpenRouter API 키를 입력하고 **연결 테스트**를 누릅니다. 키 상태(사용액·한도)를 확인하고, OpenRouter 모델 목록에서 모델 ID와 최신 단가를 자동으로 가져옵니다.
2. 언어(영어·일본어·스페인어), 수준, 말투, 상황을 고릅니다. 여행 상황은 여행지(예: 마드리드)를 입력하면 현지에 맞춰 대화합니다.
3. **대화 시작하기**를 누르면 AI가 먼저 말을 겁니다(자동으로 소리 내어 읽어 줍니다).
4. 🎤 마이크를 누르고 말하거나 타자로 입력해 보냅니다. 문장마다 바로 교정과 더 자연스러운 표현이 표시됩니다.
5. 막히면 **💡 힌트 보기**, AI 말이 어려우면 **🇰🇷 번역**을 누릅니다.
6. **대화 종료 · 리포트**를 누르면 총평, 미션 달성, 오류 유형 통계, 꼭 외울 표현이 정리됩니다.
7. **PDF / Word / Excel** 버튼으로 저장합니다. PDF는 인쇄 창에서 대상을 **PDF로 저장**으로 고르면 됩니다.

## 기본 수준

| 언어 | 기본 수준 |
|---|---|
| 영어 | A2+ 초중급 |
| 일본어 | B1 중급 (JLPT N3) |
| 스페인어 | A1 입문·초급 |

수준을 바꾸면 다음에 열 때도 기억합니다.

## 브라우저 지원

| 환경 | 음성 인식 | 음성 읽기 |
|---|---|---|
| PC Microsoft Edge | ✅ | ✅ (자연스러운 "Natural" 음성 자동 선택) |
| 갤럭시 삼성 인터넷 | ✅ | ✅ (기기에 설치된 음성) |
| 크롬 | ✅ | ✅ |
| 파이어폭스 | ❌ (타자 입력) | ✅ |

- 음성 인식은 브라우저가 제공하는 기능으로, 음성이 브라우저 회사(마이크로소프트·구글)의 서버로 보내져 처리될 수 있습니다.
- 갤럭시에서 외국어 음성이 어색하면 **설정 → 일반 관리 → 글자 읽어주기(TTS)**에서 언어 데이터를 내려받거나, 앱의 **설정 → 음성**에서 목소리를 바꿔 보세요.

## 저장되는 데이터

| 데이터 | 위치 | 언제 사라지나 |
|---|---|---|
| API 키 | sessionStorage(기본) 또는 localStorage(선택) | 탭을 닫을 때 / 직접 지울 때 |
| 설정(언어·수준·상황·모델·음성) | localStorage | 설정 초기화할 때 |
| 진행 중인 대화 | sessionStorage | 탭을 닫을 때 (새로고침은 유지) |
| 대화 기록·리포트 | 내보낸 파일(PDF·Word·Excel) | 내 PC에 계속 보관 |

## 비용

- 15턴 안팎의 대화 한 번에 대략 $0.04~0.06(약 50~80원)입니다(기본 모델 구성 기준).
- 화면 위쪽에 누적 비용이 표시되고, 리포트와 Excel 파일에 역할·모델별 비용이 기록됩니다.
- OpenRouter 대시보드에서 키별 사용 한도를 정해 두는 것을 권장합니다.

## 외부 라이브러리

내보내기 버튼을 누를 때만 CDN에서 불러옵니다.

- [SheetJS (xlsx) 0.18.5](https://cdnjs.com/libraries/xlsx): Excel 생성
- [docx 8.5.0](https://www.npmjs.com/package/docx): Word 생성
